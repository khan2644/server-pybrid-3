1️⃣ Install dependencies:
    pip install -r requirements.txt

2️⃣ config.py file mein apne API keys daal do.

3️⃣ Phir simply run karo:
    python main.py

4️⃣ Bas done — bot 24/7 ready hai ✅
