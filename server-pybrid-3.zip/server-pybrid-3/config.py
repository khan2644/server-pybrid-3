# config.py

# Telegram API credentials
api_id = 27126070
api_hash = '2736a5470b54818cd301d0cd088eb8f2'
bot_token = '7685145117:AAEQGaF9IgcAqJ4CqJ7DVv1twPIEVsEBN8U'

# Affiliaters API Token
API_TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9Iiw...'

# Your destination private/public channel username
DEST_CHANNEL = 'GalaxyZmart'
